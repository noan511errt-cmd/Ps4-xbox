# Nawaf Cloud Gaming — PS4 build notes

This repository is a branded derivative of the upstream PSBox Cloud Gaming source.
The original source files and GPL-3.0-or-later notices are retained.

## PS4 build

GitHub Actions workflow: `.github/workflows/ps4-pkg.yml`.

It installs OpenOrbis Toolchain, configures a Release build for PS4, compiles,
packages the result, and uploads the PKG as an Actions artifact. It does not
pretend that a failed compile succeeded.

### Important dependency note

The source ZIP export does not contain Git submodule contents. The workflow
initializes submodules when Git metadata is available and otherwise clones the
dependency URLs from `.gitmodules`. Upstream dependency changes can make the
project's PS4 patches fail; if that happens, use the exact dependency revisions
from the original source repository rather than weakening or skipping patch
checks.

## Versioning

For each release:
1. Update `project(xcloud_ps5 VERSION ...)` in `CMakeLists.txt`.
2. Update the version in `CMakeLists.txt`; the workflow reads it automatically.
3. Commit the changes.
4. Create and push a matching tag such as `v1.6.5`.
5. The workflow builds the PS4 PKG and attaches it to the GitHub Release.

## Data preservation

The PS4 app stores its user data under `/data/psbox`. This package keeps the
existing PS4 title ID `PSBX00001` and the data directory unchanged to maximize
in-place update compatibility. Do not change either when publishing an update.
Always install a new version over the existing installation; do not delete the
old app first. Back up `/data/psbox` before major changes.

## Performance and compatibility

The build uses `Release` optimization, as required by the project's PS4
packaging script. No speculative code-level "speed hacks" were added. Actual
streaming performance depends on console model, network, decoder support,
and the Xbox Cloud service. A successful CI build does not prove runtime
compatibility on every PS4 firmware. Test on the target console before
calling a release stable.

## Branding

The PS4 SFO title and icon/background are branded as Nawaf Cloud Gaming.
The app's internal data directory, title ID, and internal subsystem identifiers
are intentionally retained to protect existing data and upgrade identity.


## Importing the project from a phone

If GitHub's Android file picker cannot upload folders, create a new empty repository,
upload this complete ZIP file to the repository root, and create the workflow file
at `.github/workflows/ps4-pkg.yml` using the workflow supplied with this archive.
The workflow detects the ZIP, extracts the project into the runner, then builds it.
Do not rename the ZIP unless you also adjust the archive search in the workflow.

The `.github` directory is hidden on some Android file managers. It is still included
inside this ZIP; do not omit it when uploading the extracted project.

## Build caveat

The ZIP format does not retain Git submodule commit IDs. The workflow therefore
fetches the current upstream dependency heads. The project's PS4 patches may not
apply to a newer dependency revision. If that happens, the workflow must be updated
to pin the exact dependency commits compatible with these patches; it must not skip
the patch checks or upload a fake/empty PKG.
