// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 RafaelNGP
// Xbox Live token exchange: MSA access token -> Xbox user token -> XSTS
// token for a relying party (gssv for xCloud, xboxlive.com for profile data).
#pragma once

#include <cstdint>
#include <string>

namespace xc::auth {

struct XblToken {
    std::string token;
    std::string userHash;  // "uhs"
    std::string gamertag;  // only for relying parties that return it
    std::string xuid;
    std::string notAfter;  // ISO-8601

    // Value of the Authorization header used by *.xboxlive.com services.
    std::string authorizationHeader() const { return "XBL3.0 x=" + userHash + ";" + token; }
};

namespace rp {
constexpr const char* kGssv = "http://gssv.xboxlive.com/";
constexpr const char* kXboxLive = "http://xboxlive.com";
constexpr const char* kMarketplace = "http://mp.microsoft.com/";  // store / subscriptions
}  // namespace rp

// `rpsPrefix` is "t=" for login.live.com tokens issued to a custom client id,
// "d=" for MSAL/v2.0 tokens. `redirectUrl` (optional) extracts Microsoft's Redirect URL on refusal.
bool xblUserToken(const std::string& msaAccessToken, const std::string& rpsPrefix, XblToken& out,
                  std::string& err, std::string* redirectUrl = nullptr);
bool xstsToken(const XblToken& userToken, const std::string& relyingParty, XblToken& out,
               std::string& err, std::string* redirectUrl = nullptr);

// An ISO-8601 UTC time ("2026-10-19T09:12:34.1234567Z", a token's NotAfter)
// as unix seconds; 0 when it can't be read.
int64_t parseIsoUtc(const std::string& iso);

}  // namespace xc::auth
