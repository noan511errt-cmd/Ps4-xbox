// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 RafaelNGP
#include "ui/canvas.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace xc::ui {

namespace {

constexpr float kPi = 3.14159265f;

Rect intersect(Rect a, Rect b) {
    int x0 = std::max(a.x, b.x), y0 = std::max(a.y, b.y);
    int x1 = std::min(a.x + a.w, b.x + b.w), y1 = std::min(a.y + a.h, b.y + b.h);
    return {x0, y0, std::max(0, x1 - x0), std::max(0, y1 - y0)};
}

inline uint32_t lerp8(uint32_t a, uint32_t b, uint32_t t /*0..255*/) { return a + (((b - a) * t + 128) >> 8); }

inline uint32_t clampCoverage(float v) {
    if (v <= 0) return 0;
    if (v >= 1) return 255;
    return static_cast<uint32_t>(v * 255.0f + 0.5f);
}

constexpr int kMaxLutRadius = 32;

// Fast precomputed table for corner coverage: s_cornerLut.get(radius, ix, iy)
struct CornerCoverageLut {
    uint8_t table[kMaxLutRadius + 1][kMaxLutRadius * kMaxLutRadius];

    void init() {
        for (int r = 1; r <= kMaxLutRadius; ++r) {
            for (int iy = 0; iy < r; ++iy) {
                for (int ix = 0; ix < r; ++ix) {
                    float dx = ix + 0.5f;
                    float dy = iy + 0.5f;
                    float d = std::sqrt(dx * dx + dy * dy);
                    float v = r + 0.5f - d;
                    uint8_t cov = v <= 0.0f ? 0 : v >= 1.0f ? 255 : static_cast<uint8_t>(v * 255.0f + 0.5f);
                    table[r][iy * r + ix] = cov;
                }
            }
        }
    }

    uint32_t get(int radius, int ix, int iy) const {
        return table[radius][iy * radius + ix];
    }
};

static CornerCoverageLut s_cornerLut;
static bool s_lutInit = [] { s_cornerLut.init(); return true; }();

}  // namespace

void Canvas::setClip(Rect r) { clip_ = intersect(r, {0, 0, w_, h_}); }

inline void Canvas::blend(uint32_t& dst, Color src, uint32_t a) const {
    if (a == 0) return;
    if (a >= 255) {
        dst = src | 0xFF000000u;
        return;
    }
    uint32_t d = dst;
    uint32_t inv = 255 - a;
    uint32_t rb = (((src & 0x00FF00FFu) * a + (d & 0x00FF00FFu) * inv + 0x00800080u) >> 8) & 0x00FF00FFu;
    uint32_t g = (((src & 0x0000FF00u) * a + (d & 0x0000FF00u) * inv + 0x00008000u) >> 8) & 0x0000FF00u;
    dst = 0xFF000000u | rb | g;
}

void Canvas::clear(Color c) { std::fill(px_.begin(), px_.end(), c | 0xFF000000u); }

uint32_t Canvas::cornerCoverage(Rect r, int radius, int px, int py) {
    int left = r.x + radius, right = r.x + r.w - radius;
    int top = r.y + radius, bottom = r.y + r.h - radius;

    int ix = px < left ? (left - 1 - px) : px >= right ? (px - right) : -1;
    int iy = py < top ? (top - 1 - py) : py >= bottom ? (py - bottom) : -1;

    if (ix < 0 || iy < 0) return 255;

    if (radius <= kMaxLutRadius) {
        return s_cornerLut.get(radius, ix, iy);
    }

    float dx = ix + 0.5f, dy = iy + 0.5f;
    float d2 = dx * dx + dy * dy;
    float rInner = radius - 0.5f;
    if (d2 <= rInner * rInner) return 255;
    float rOuter = radius + 0.5f;
    if (d2 >= rOuter * rOuter) return 0;

    return clampCoverage(radius + 0.5f - std::sqrt(d2));
}

void Canvas::fillRect(Rect r, Color c, int radius) {
    Rect b = intersect(r, clip_);
    uint32_t a = alphaOf(c);
    if (b.w <= 0 || b.h <= 0 || a == 0) return;
    radius = std::min(radius, std::min(r.w, r.h) / 2);
    uint32_t opaqueVal = c | 0xFF000000u;
    for (int y = b.y; y < b.y + b.h; ++y) {
        uint32_t* row = &px_[static_cast<size_t>(y) * w_];
        bool cornerRow = radius > 0 && (y < r.y + radius || y >= r.y + r.h - radius);
        if (!cornerRow) {
            if (a >= 255) {
                std::fill_n(&row[b.x], b.w, opaqueVal);
            } else {
                for (int x = b.x; x < b.x + b.w; ++x) blend(row[x], c, a);
            }
        } else {
            int leftEnd = std::min(b.x + b.w, r.x + radius);
            int rightStart = std::max(b.x, r.x + r.w - radius);
            for (int x = b.x; x < b.x + b.w; ++x) {
                uint32_t cov = 255;
                if (x < leftEnd || x >= rightStart) cov = cornerCoverage(r, radius, x, y);
                blend(row[x], c, (a * cov + 127) / 255);
            }
        }
    }
}

void Canvas::strokeRect(Rect r, Color c, int t, int radius) {
    Rect b = intersect(r, clip_);
    uint32_t a = alphaOf(c);
    if (b.w <= 0 || b.h <= 0 || a == 0) return;
    Rect inner{r.x + t, r.y + t, r.w - 2 * t, r.h - 2 * t};
    int innerRadius = std::max(0, radius - t);

    int holeX0 = inner.x + innerRadius;
    int holeX1 = inner.x + inner.w - innerRadius;
    int holeY0 = inner.y + innerRadius;
    int holeY1 = inner.y + inner.h - innerRadius;

    for (int y = b.y; y < b.y + b.h; ++y) {
        uint32_t* row = &px_[static_cast<size_t>(y) * w_];
        bool inHoleY = (y >= holeY0 && y < holeY1 && holeX1 > holeX0);

        for (int x = b.x; x < b.x + b.w; ++x) {
            if (inHoleY && x == holeX0) {
                x = holeX1 - 1;
                continue;
            }
            uint32_t outer = radius == 0 ? 255 : cornerCoverage(r, radius, x, y);
            uint32_t in = 0;
            if (x >= inner.x && x < inner.x + inner.w && y >= inner.y && y < inner.y + inner.h)
                in = innerRadius ? cornerCoverage(inner, innerRadius, x, y) : 255;
            uint32_t cov = outer > in ? outer - in : 0;
            if (cov) blend(row[x], c, (a * cov + 127) / 255);
        }
    }
}

void Canvas::gradientV(Rect r, Color top, Color bottom) {
    Rect b = intersect(r, clip_);
    if (b.w <= 0 || b.h <= 0) return;
    for (int y = b.y; y < b.y + b.h; ++y) {
        uint32_t t = r.h > 1 ? static_cast<uint32_t>((y - r.y) * 255 / (r.h - 1)) : 0;
        Color c = 0;
        for (int s = 0; s < 32; s += 8) c |= lerp8((top >> s) & 0xFF, (bottom >> s) & 0xFF, t) << s;
        uint32_t a = alphaOf(c);
        if (a == 0) continue;
        uint32_t* row = &px_[static_cast<size_t>(y) * w_];
        if (a >= 255) {
            std::fill_n(&row[b.x], b.w, c | 0xFF000000u);
        } else {
            uint32_t s_rb = (c & 0x00FF00FFu) * a + 0x00800080u;
            uint32_t s_g  = (c & 0x0000FF00u) * a + 0x00008000u;
            uint32_t inv  = 255 - a;
            for (int x = b.x; x < b.x + b.w; ++x) {
                uint32_t d = row[x];
                uint32_t rb = ((s_rb + (d & 0x00FF00FFu) * inv) >> 8) & 0x00FF00FFu;
                uint32_t g  = ((s_g  + (d & 0x0000FF00u) * inv) >> 8) & 0x0000FF00u;
                row[x] = 0xFF000000u | rb | g;
            }
        }
    }
}

void Canvas::gradientH(Rect r, Color left, Color right) {
    Rect b = intersect(r, clip_);
    if (b.w <= 0 || b.h <= 0) return;
    Color stackCols[2048];
    std::vector<Color> heapCols;
    Color* cols = b.w <= 2048 ? stackCols : (heapCols.resize(static_cast<size_t>(b.w)), heapCols.data());
    for (int x = b.x; x < b.x + b.w; ++x) {
        uint32_t t = r.w > 1 ? static_cast<uint32_t>((x - r.x) * 255 / (r.w - 1)) : 0;
        Color c = 0;
        for (int s = 0; s < 32; s += 8) c |= lerp8((left >> s) & 0xFF, (right >> s) & 0xFF, t) << s;
        cols[static_cast<size_t>(x - b.x)] = c;
    }
    for (int y = b.y; y < b.y + b.h; ++y) {
        uint32_t* row = &px_[static_cast<size_t>(y) * w_];
        for (int x = b.x; x < b.x + b.w; ++x) {
            Color c = cols[static_cast<size_t>(x - b.x)];
            blend(row[x], c, alphaOf(c));
        }
    }
}

void Canvas::fillCircle(float cx, float cy, float radius, Color c) {
    Rect r{static_cast<int>(cx - radius - 1), static_cast<int>(cy - radius - 1), static_cast<int>(radius * 2 + 3),
           static_cast<int>(radius * 2 + 3)};
    Rect b = intersect(r, clip_);
    uint32_t a = alphaOf(c);
    for (int y = b.y; y < b.y + b.h; ++y)
        for (int x = b.x; x < b.x + b.w; ++x) {
            float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
            uint32_t cov = clampCoverage(radius + 0.5f - std::sqrt(dx * dx + dy * dy));
            if (cov) blend(px_[static_cast<size_t>(y) * w_ + x], c, (a * cov + 127) / 255);
        }
}

void Canvas::strokeCircle(float cx, float cy, float radius, float thickness, Color c) {
    float outer = radius + thickness / 2, inner = radius - thickness / 2;
    Rect r{static_cast<int>(cx - outer - 1), static_cast<int>(cy - outer - 1), static_cast<int>(outer * 2 + 3),
           static_cast<int>(outer * 2 + 3)};
    Rect b = intersect(r, clip_);
    uint32_t a = alphaOf(c);
    for (int y = b.y; y < b.y + b.h; ++y)
        for (int x = b.x; x < b.x + b.w; ++x) {
            float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
            float d = std::sqrt(dx * dx + dy * dy);
            uint32_t cov = std::min(clampCoverage(outer + 0.5f - d), clampCoverage(d - inner + 0.5f));
            if (!cov) continue;
            blend(px_[static_cast<size_t>(y) * w_ + x], c, (a * cov + 127) / 255);
        }
}

void Canvas::strokeArc(float cx, float cy, float radius, float thickness, float start, float sweep, Color c) {
    float outer = radius + thickness / 2, inner = radius - thickness / 2;
    Rect r{static_cast<int>(cx - outer - 1), static_cast<int>(cy - outer - 1), static_cast<int>(outer * 2 + 3),
           static_cast<int>(outer * 2 + 3)};
    Rect b = intersect(r, clip_);
    uint32_t a = alphaOf(c);
    start = std::fmod(start, 2 * kPi);
    if (start < 0) start += 2 * kPi;
    for (int y = b.y; y < b.y + b.h; ++y)
        for (int x = b.x; x < b.x + b.w; ++x) {
            float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
            float d = std::sqrt(dx * dx + dy * dy);
            uint32_t cov = std::min(clampCoverage(outer + 0.5f - d), clampCoverage(d - inner + 0.5f));
            if (!cov) continue;
            float ang = std::atan2(dy, dx);
            if (ang < 0) ang += 2 * kPi;
            float rel = ang - start;
            if (rel < 0) rel += 2 * kPi;
            if (rel > sweep) continue;
            // Fade the tail for a spinner look.
            uint32_t fade = static_cast<uint32_t>(255 * (0.25f + 0.75f * rel / sweep));
            blend(px_[static_cast<size_t>(y) * w_ + x], c, a * cov / 255 * fade / 255);
        }
}

void Canvas::line(float x0, float y0, float x1, float y1, float thickness, Color c) {
    float half = thickness / 2;
    Rect r{static_cast<int>(std::min(x0, x1) - half - 1), static_cast<int>(std::min(y0, y1) - half - 1),
           static_cast<int>(std::fabs(x1 - x0) + thickness + 3), static_cast<int>(std::fabs(y1 - y0) + thickness + 3)};
    Rect b = intersect(r, clip_);
    float vx = x1 - x0, vy = y1 - y0, len2 = vx * vx + vy * vy;
    uint32_t a = alphaOf(c);
    for (int y = b.y; y < b.y + b.h; ++y)
        for (int x = b.x; x < b.x + b.w; ++x) {
            float px = x + 0.5f - x0, py = y + 0.5f - y0;
            float t = len2 > 0 ? std::clamp((px * vx + py * vy) / len2, 0.0f, 1.0f) : 0;
            float dx = px - t * vx, dy = py - t * vy;
            uint32_t cov = clampCoverage(half + 0.5f - std::sqrt(dx * dx + dy * dy));
            if (cov) blend(px_[static_cast<size_t>(y) * w_ + x], c, (a * cov + 127) / 255);
        }
}

void Canvas::drawImage(const Image& img, int x, int y, uint8_t opacity, int radius) {
    Rect r{x, y, img.w, img.h};
    Rect b = intersect(r, clip_);
    if (b.w <= 0 || b.h <= 0 || opacity == 0) return;
    bool circle = radius < 0;
    if (circle) radius = std::min(img.w, img.h) / 2;
    radius = std::min(radius, std::min(img.w, img.h) / 2);
    for (int yy = b.y; yy < b.y + b.h; ++yy) {
        uint32_t* row = &px_[static_cast<size_t>(yy) * w_];
        const uint32_t* src = &img.px[static_cast<size_t>(yy - y) * img.w];
        bool cornerRow = radius > 0 && (circle || yy < y + radius || yy >= y + img.h - radius);
        if (!cornerRow && img.opaque) {
            if (opacity >= 255) {
                std::memcpy(&row[b.x], &src[b.x - x], static_cast<size_t>(b.w) * sizeof(uint32_t));
            } else {
                for (int xx = b.x; xx < b.x + b.w; ++xx) {
                    blend(row[xx], src[xx - x], opacity);
                }
            }
            continue;
        }
        for (int xx = b.x; xx < b.x + b.w; ++xx) {
            uint32_t s = src[xx - x];
            uint32_t a = (alphaOf(s) * opacity + 127) / 255;
            if (cornerRow && (circle || xx < x + radius || xx >= x + img.w - radius))
                a = a * cornerCoverage(r, radius, xx, yy) / 255;
            blend(row[xx], s, a);
        }
    }
}

void Canvas::drawMask(const uint8_t* mask, int mw, int mh, int stride, int x, int y, Color c) {
    Rect b = intersect({x, y, mw, mh}, clip_);
    uint32_t a = alphaOf(c);
    for (int yy = b.y; yy < b.y + b.h; ++yy) {
        uint32_t* row = &px_[static_cast<size_t>(yy) * w_];
        const uint8_t* m = mask + static_cast<size_t>(yy - y) * stride;
        for (int xx = b.x; xx < b.x + b.w; ++xx) {
            uint32_t cov = m[xx - x];
            if (cov) blend(row[xx], c, (a * cov + 127) / 255);
        }
    }
}

}  // namespace xc::ui
