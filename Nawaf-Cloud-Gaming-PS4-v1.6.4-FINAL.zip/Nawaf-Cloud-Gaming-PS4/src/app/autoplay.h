// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 RafaelNGP
// Unattended test mode (tools/ps5/autotest.sh).
// <dataDir>/autoplay.txt holds "<titleId> <seconds> [option]". The app signs
// in, plays that title for that long (pressing A at 15 s and 20 s), saves
// decoded frames and logs "AUTOPLAY END". Options, comma-separated: nosimd,
// dump, repeat, idle (no A presses), threads=N (H.264 decoder threads),
// rumbletest (rumbles the pad for 1.5 s at start), triggertest (the triggers
// for 3 s), vibetest (each motor and trigger alone, announced, no game),
// droptest (the connection dropped at 20 s: the stream reconnects), loss=N
// (N% of the video packets held back until NACKed), detailtest (opens a game to
// buy far down the list instead of playing, saves detail.ppm), imetest (opens
// the system keyboard on the home screen), menutest (in the game: the menu,
// 720p, back to 1080p), res=720p|1080p|1080p-hq|1440p, sharp=0..3 and
// deband=0..3 and ai (Anime4K) instead of the settings.
// The title "BENCH" decodes <dataDir>/sample.h264 instead; "XHOME" plays
// the account's first own console; "UPDATE" stays on the home screen (the
// update test: updatefeed=<url> of a release, testca to trust
// <dataDir>/test-ca.pem, updatetest to accept the pop-up, norestart).
#pragma once

#include "input/controller.h"
#include "ui/app_ui.h"
#include "ui/canvas.h"

#include <atomic>
#include <cstdint>
#include <string>

namespace xc::app {

struct Autoplay {
    std::string title;  // empty: not testing
    int seconds = 0;
    bool dump = false;
    int runs = 1;
    bool idle = false;
    bool consolesTab = false;    // "consolestab": open My consoles, save consoles.ppm
    bool consolesEmpty = false;  // with "consolestab": as if none were found
    bool checkSignInTest = false;// "checksignintest": open sign-in check, verify 6 stages, save signin_check.ppm
    bool freeTest = false;       // "freetest": simulate free account, verify FREE badge and game locks
    bool settingsTest = false;   // "settingstest": open the resolution list, save settings.ppm
    bool trophyTest = false;     // "trophytest": open settings, focus row 24 (Sync Trophies), test sync, save trophy_settings.ppm
    bool trophySyncTest = false; // "trophysynctest": open settings, enable sync, capture progress, retain trophies
    bool psboxSelfTest = false;  // "psboxself": native v1 trophy self-test bound to PSBox's own title (PPSA99810)
    bool keysTest = false;       // "keystest": Settings' groups, the keyboard keys' screen, a key chosen (keys*.ppm)
    bool padMapTest = false;     // "padmaptest": the controller buttons' screen, a press captured, an incomplete map (padmap*.ppm)
    bool badCa = false;          // "badca": a missing CA bundle: the built-in copy must be used
    bool consoles = false;       // "consoles": log the account's own consoles (xhome)
    bool pad = false;            // "pad": the physical pad stays in use, its buttons logged
    bool padSpkTest = false;     // "padspktest": play queue-ready chime and vibration on controller speaker
    bool queueUiTest = false;    // "queueuitest": open settings, focus queueReadyAlert row, test sound with Square
    bool wishlistTest = false;   // "wishlisttest": test wishlist filter, empty state, and active wishlisted items
    bool block1Test = false;     // "block1test": verify 3x3 filter grid, settings descriptions, free acquire button, and loading tips
    bool block2Test = false;     // "block2test": verify update prompt 3 buttons, notes modal, pad speaker volume, and bitrate caps
    bool block3Test = false;     // "block3test": verify web server qr in settings and official age rating on details
    bool touchpadTest = false;   // "touchpadtest": verify touchpad shortcuts modal, stream menu slots with Phone icon, and loading screen
    bool bitrateTest = false;    // "bitratetest": open settings, focus Bitrate row, test slider, save settings_bitrate_caps.ppm
    bool detailTest = false;     // open a game to buy far down the list, save its page
    bool libraryTest = false;    // open "Your games", save it at 4 s and 25 s
    bool mouseTest = false;      // "mousetest": move mouse cursor and save mouse.ppm
    bool mw4Test = false;        // "mw4test": search and open details for Call of Duty MW4
    bool v150Test = false;       // "v150test": verify new settings order and search gratis filter
    bool claimTest = false;      // "claimtest": test free game acquisition, library persistence, and game launch
    bool vkTest = false;         // the GPU presenting instead of the CPU display
    bool hz60 = false;           // hz60: streams stay at 60 Hz output (no 120 Hz switch)
    bool fnPlay = false;         // fnplay: Fortnite gameplay for measurements (Play once, then the camera turns and the player runs)
    bool legacy = false;         // legacy: the stream as it was tuned before 2026-11-04 (the A/B baseline)
    bool imgTest = false;        // imgtest: 25 s before the end, one picture drawn with each look (img_*.ppm)
    int64_t cloudLeft = -1;      // cloudleft=N: a stream counts down from N seconds left (the menu, the notices)
    int abCycleSec = 0;          // abcycle=N: A/B conditions in one stream, the next every N s (worker_stream.cpp)
    bool cloudTimeTest = false;  // cloudtimetest: the cloud time line (4 h 10 of 15 h, 1 h 30, none, unlimited), the game menu with it, the time-up error
    bool cpuDisplay = false;     // the CPU display even where the GPU comes up
    int upscaler = -1;           // ai: Anime4K instead of the setting
    bool restore = false;        // restore: Anime4K Restore before the upscale
    bool dropTest = false;       // droptest: the connection dropped at 20 s
    bool hwDecode = false;       // hwdecode: the hardware decoder alongside, logged
    bool preferHwDecode = true;  // hardware video decoding preferred by default
    bool swDecode = false;       // swdecode: force software CPU decoding
    bool vibeTest = false;       // each motor alone, with a notification
    bool imeTest = false;        // open the system keyboard on the home screen
    bool menuTest = false;       // in the game: open the menu, switch to 720p
    int decodeThreads = 1;
    int videoLoss = 0;
    bool kbHints = false;  // kbhints: as if a keyboard were plugged in and used           // loss=N: N% of the video packets held back, delivered when NACKed
    int deband = -1;             // deband=0..3: instead of the setting
    int sharpness = -1;          // sharp=0..3: instead of the setting
    int bitrateMbps = 0;         // bitrate=N or mbps=N: bitrate ceiling in Mbps
    std::string resolution;      // res=720p|1080p|1440p: instead of the setting
    std::string updateFeed;      // updatefeed=<url>: the release JSON instead of GitHub's
    bool testCa = false;         // testca: also trust <dataDir>/test-ca.pem (the feed's server)
    bool updateTest = false;     // updatetest: accept the update pop-up, save update.ppm / updating.ppm
    bool updateSkip = false;     // updateskip: "Not now" on the update pop-up
    bool settingsUpdate = false; // settingsupdate: Settings > Updates, Cross
    bool crashTest = false;      // crashtest: a SIGSEGV on the home screen (the next start must offer its report)
    bool scrollTest = false;     // scrolltest: the right stick and a touchpad swipe page through the lists (logged)
    bool quickTest = false;      // quicktest: cross-gen pairs' badges, MOBA games, the lock on `lockTitle`
    std::string lockTitle;       // locktitle=<xCloud title id>: logged playable or locked at once
    bool searchTest = false;     // searchtest: lowest price, Game Pass co-op + dubbed, the genres' list
                                 // (cheapest.ppm, filters.ppm, genres.ppm)
    bool tuneTest = false;       // tunetest: the dead zone's stick tester and the trigger tester (sticks.ppm, triggers.ppm)
    bool confirmTest = false;    // confirmtest: physical Cross / Circle presses through Settings > Confirm button
    bool menuShot = false;       // menushot: the game menu open over the 10 s snapshot (screen.ppm)
    bool pickerTest = false;     // pickertest: the confirm button's list (confirm.ppm), the light
                                 // bar's colour picker moved (picker.ppm), chosen (settings.ppm)
    bool noRestart = false;      // norestart: after an update, close instead of restarting
    bool gridTest = false;       // gridtest: navigate to All games grid, verify 2D navigation and capture screenshots
    bool gameSettingsTest = false; // gamesettingstest: test details and game settings modal
    bool publisherTest = false;  // publishertest: test publisher filter dropdown and search results
    bool friendsTest = false;    // friendstest: test friends playing row and card badge
    bool streamMenuTest = false; // streammenutest: render StreamMenu with mic and audio route options
    bool tlsCheck = false;       // tlscheck: refused certificates (badssl.com) classified and logged, nothing else
    bool regionTest = false;     // regiontest: the refused sign-in (region.ppm), its country list (region_picker.ppm,
                                 // closed unchanged), Settings on the sign-in country (region_settings.ppm), back
                                 // (region_back.ppm). The sign-in country is never changed.
    bool donationTest = false;   // donationtest: navigate to Settings row 19, open donation modal, save donation.ppm
    bool reportTest = false;     // reporttest: open Settings, press Triangle for Report a problem, save report.ppm
};
extern Autoplay g_autoplay;
extern std::atomic<bool> g_syntheticA;  // A held down for the game
extern std::atomic<float> g_syntheticRightX, g_syntheticLeftY;  // sticks for the game (fnplay)

void loadAutoplay();
// After loadAutoplay(), before the settings are read. Starting in autoplay
// mode, settings.json is copied to settings.autoplay-backup.json (once: a
// backup already there, from a run before, is the user's and is kept);
// starting without autoplay.txt, such a backup is put back over
// settings.json and deleted. A test that misbehaves or is killed can't
// leave the user's settings changed.
void guardSettingsForAutoplay(const std::string& settingsPath);
// A test stream ended: the next run, or "AUTOPLAY END".
void autoplayFinished(const std::string& result);
void runDecodeBench();

// Main thread, each pass. The pad as read: kept from the tests (or logged).
void autoplayPad(input::ControllerState& pad);
// Before the screen gets `nav`: the scripted presses (menutest, settingstest).
void autoplayNav(ui::NavInput& nav, bool& menuCombo, uint64_t now);
// Off the stream, after the UI handled its input: the snapshots and the
// tests on the home screen.
void autoplayScreens(const ui::Canvas& canvas, uint64_t now);

}  // namespace xc::app
